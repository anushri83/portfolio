<?php>
if($_SERVER['REQUEST_METHOD']=="POST"){
    $email=$_POST['email']
    $password=$_POST['password']
    $conn=mysqli_connect("localhost","root","","blood_database");
    $res=mysqli_query($conn,"select* from blood_database where '$email'=email and '$password'=password")
    if(mysqli_num_rows==1){
        echo("login successfull")
    }
    else{
        echo("Invalid")
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>Registration</title>
</head>
<body class="body">
    <div class="container">
        <form class="forms">
            <h1>LOGIN</h1>
            <div>
                <label for="Email" >Email</label>
                <input type="text" id="Email" name=<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>Registration</title>
    <style>
       .body{
        background-color: rgb(248, 233, 233);
        font-family: sans-serif;
      }
      main{
        padding:0px 400px; 
        height: 50vh;
        margin: 100px 500px;
      }
      div{
        margin-bottom: 25px;
        font-size: 20px;
      }
      input {
        width: 100%;
        padding: 7px ;
        margin-top: 10px;
      }
      .log{
        border: rgb(56, 54, 54) solid 2px;
        padding: 40px;
      }
      center{
        color: red;
        font-size: 15px;
        font-weight: 400;
      }
      button{
        background-color: blue;
        color: white;
        font-size: 20px;
        padding: 10px 20px;
        border-radius: 10px;
        text-align: center;
        width: 100%;
        cursor: pointer;
      }
    </style>
</head>
<body class="body">
    <main class="log">
        <form class="forms">
            <center><h1>LOGIN</h1></center>
            <div>
                <label for="Email" >Email</label>
                <input type="text" id="Email" name="Email"placeholder="Email"></div>
          <div>
                <label for="Password" >Password</label>
                <input type="password" id="Password" name="Password"placeholder="Password"><br><br>
           </div>   
        
                
                <button  type="button" c>LOGIN</button>
            </div>
        </form>
    </main>
<script src="index.js" charset="utf-8"></script>

</body>
</html>"Email"placeholder="Email">
                <label for="Password" >Password</label>
                <input type="password" id="Password" name="Password"placeholder="Password"><br><br>
                <div class="row-g-2">     
        
                </div>
                <button  type="button" class="btn btn-primary btn-lg">LOGIN</button>
            </div>
        </form>
    </div>
<script src="index.js" charset="utf-8"></script>

</body>
</html>
<php?>
if($_SERVER['REQUEST_METHOD']=="POST"){
    $name=$_POST['name']
    $email=$_POST['email']
    $password=$_POST['password']
    $city=$_POST['City']
    $bloodgroup=$_POST['BloodGroup']
    $conn=mysqli_connect("localhost","root","","blood_database");
    $q=mysqli_query($conn,"insert into data () values()")
    if()
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles.css">
    <title>Document</title>
    <style>
      .body{
        background-color: rgb(248, 233, 233);
        font-family: sans-serif;
      }
      main{
        padding:0px 400px; 
        height: 90vh;
        margin: 50px 450px;
      }
      center{
        color: red;
        font-size: 25px;
        font-weight: 500;
      }
      div{
        margin-bottom: 25px;
        font-size: 20px;
      }
      input ,select{
        width: 100%;
        padding: 7px ;
        margin-top: 10px;
      }
      button{
        background-color: blue;
        color: white;
        font-size: 20px;
        padding: 10px 20px;
        border-radius: 10px;
        text-align: center;
        width: 100%;
        cursor: pointer;
      }
      .log{
        border: rgb(56, 54, 54) solid 2px;
        padding: 40px;
      }
      .other{      
        display: flex;
        justify-content: space-between;
        font-size: 20px;
      }
    </style>
</head>
<body class="body">
  <main class="log">
    <u><center>REGISTRATION</center></u><br><br>
        <form action="" method="post">
            <div>
              <label >Enter Your Name  </label>
              <input type="text" name="name"  placeholder="Name" required>
            </div>
            <div>
              <label>Enter Your Email </label>
              <input type="email" name="email" placeholder="example@gmail.com">
            </div>
              <div>
              <label >Password  </label>
              <input type="password" name="password" placeholder="#" required="">
              </div>
              <div>
                <label>City  </label>
                <select name=city required="">
                  <option value="">Choose...</option>
                  <option value="mumbai">Mumbai</option>
                  <option value="pune">Pune</option>
                  <option value="nagpur">Nagpur</option>
                  <option value="nashik">Nashik</option>
                  <option value="ahmednagar">Ahmednagar</option>
                  <option value="alibag">Alibag</option>
                </select>
            </div>
            <div>
              <label >Blood group</label>
              <input type="text" name="BloodGroup" placeholder="Enter BloodGroup" required="">        
            </div>
          <button type="submit">Continue to Login</button><br><br>
          <div class="other">
          <a href="./login.php"> login</a>
          <a href="./update.php"> forget password</a>
        </div>
        </form>
  </main>
</body>
</html>
